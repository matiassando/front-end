// src/components/NoteForm.jsx
import { useState } from "react";
import { sanitizeTitle, sanitizeDescription, LIMITS } from "../utils/sanitize";

/**
 * Formulario para crear una nueva nota.
 * Regla de negocio: la descripción es obligatoria, el título y el
 * check de "importante" son opcionales.
 */
function NoteForm({ onAddNote }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [important, setImportant] = useState(false);
  const [error, setError] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    const cleanDescription = sanitizeDescription(description);
    const cleanTitle = sanitizeTitle(title);

    if (!cleanDescription) {
      setError("La descripción es obligatoria.");
      return;
    }

    onAddNote({
      title: cleanTitle,
      description: cleanDescription,
      important,
    });

    setTitle("");
    setDescription("");
    setImportant(false);
    setError("");
  }

  return (
    <form className="note-form" onSubmit={handleSubmit}>
      <h1 className="note-form__brand">Post It Simulator</h1>

      <div className="note-form__fields">
        <input
          type="text"
          className="note-form__input"
          placeholder="Título (opcional)"
          value={title}
          maxLength={LIMITS.TITLE}
          onChange={(event) => setTitle(event.target.value)}
        />

        <input
          type="text"
          className="note-form__input note-form__input--grow"
          placeholder="Descripción"
          value={description}
          maxLength={LIMITS.DESCRIPTION}
          onChange={(event) => {
            setDescription(event.target.value);
            if (error) setError("");
          }}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? "description-error" : undefined}
        />

        <label className="note-form__checkbox">
          <input
            type="checkbox"
            checked={important}
            onChange={(event) => setImportant(event.target.checked)}
          />
          <span>¡Importante!</span>
        </label>

        <button type="submit" className="note-form__submit">
          Pegar nota
        </button>
      </div>

      {error && (
        <p id="description-error" className="note-form__error" role="alert">
          {error}
        </p>
      )}
    </form>
  );
}

export default NoteForm;
