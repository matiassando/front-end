// src/components/Note.jsx

/**
 * Una sola nota adhesiva.
 * La rotación leve por nota viene calculada en el padre (NoteBoard)
 * a partir del id, para que sea estable entre renders pero distinta
 * por nota (efecto "pegado a mano").
 */
function Note({ note, rotation, onDelete }) {
  const { id, title, description, important } = note;

  return (
    <article
      className={`note${important ? " note--important" : ""}`}
      style={{ "--rotation": `${rotation}deg` }}
    >
      <span className="note__pin" aria-hidden="true" />

      <button
        type="button"
        className="note__delete"
        onClick={() => onDelete(id)}
        aria-label={`Eliminar nota ${title || "sin título"}`}
      >
        ×
      </button>

      {title && <h2 className="note__title">{title}</h2>}
      <p className="note__description">{description}</p>
    </article>
  );
}

export default Note;
