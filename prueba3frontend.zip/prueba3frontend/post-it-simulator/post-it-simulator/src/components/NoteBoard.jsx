// src/components/NoteBoard.jsx
import Note from "./Note";

/**
 * Calcula una rotación pseudo-aleatoria pero estable a partir del id
 * de la nota, para que el layout se vea "pegado a mano" sin que las
 * notas bailen entre renders.
 */
function rotationFromId(id) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = (hash << 5) - hash + id.charCodeAt(i);
    hash |= 0;
  }
  // Rango de -2.5° a 2.5°
  return ((hash % 50) / 10) - 2.5;
}

function NoteBoard({ notes, onDelete }) {
  if (notes.length === 0) {
    return (
      <div className="note-board note-board--empty">
        <p>El escritorio está vacío. Escribe algo y pégalo aquí arriba.</p>
      </div>
    );
  }

  return (
    <div className="note-board">
      {notes.map((note) => (
        <Note
          key={note.id}
          note={note}
          rotation={rotationFromId(note.id)}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}

export default NoteBoard;
