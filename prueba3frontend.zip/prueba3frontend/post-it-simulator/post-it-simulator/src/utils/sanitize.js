// src/utils/sanitize.js
// Buenas prácticas de seguridad: el título y la descripción son texto
// libre ingresado por la persona usuaria. React ya escapa el contenido
// al renderizarlo (evita inyección de HTML/XSS), pero igualmente
// normalizamos el texto antes de guardarlo: quitamos espacios sobrantes
// y limitamos la longitud para que el Local Storage no crezca sin control.

const MAX_TITLE_LENGTH = 60;
const MAX_DESCRIPTION_LENGTH = 280;

export function sanitizeTitle(value) {
  return value.trim().slice(0, MAX_TITLE_LENGTH);
}

export function sanitizeDescription(value) {
  return value.trim().slice(0, MAX_DESCRIPTION_LENGTH);
}

export const LIMITS = {
  TITLE: MAX_TITLE_LENGTH,
  DESCRIPTION: MAX_DESCRIPTION_LENGTH,
};
