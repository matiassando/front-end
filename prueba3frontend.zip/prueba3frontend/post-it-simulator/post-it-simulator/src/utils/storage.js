// src/utils/storage.js
// Capa de acceso a Local Storage para las notas.
// Centraliza la lectura/escritura y valida la integridad de los datos
// para que un valor corrupto o manipulado no rompa la aplicación.

const STORAGE_KEY = "post-it-simulator:notes";

/**
 * Valida que un objeto tenga la forma esperada de una nota.
 * Una nota "corrupta" (campos faltantes, tipos incorrectos) se descarta
 * en vez de provocar un error en tiempo de ejecución.
 */
function isValidNote(note) {
  return (
    note &&
    typeof note === "object" &&
    typeof note.id === "string" &&
    typeof note.description === "string" &&
    note.description.trim().length > 0 &&
    typeof note.title === "string" &&
    typeof note.important === "boolean" &&
    typeof note.createdAt === "number"
  );
}

/**
 * Lee y valida todas las notas almacenadas.
 * Si el contenido guardado no es JSON válido o no es un arreglo,
 * se recupera de forma segura devolviendo una lista vacía.
 */
export function loadNotes() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.filter(isValidNote);
  } catch (error) {
    console.warn("No se pudo leer Local Storage, se reinicia la lista de notas.", error);
    return [];
  }
}

/**
 * Persiste el arreglo de notas en Local Storage.
 * Filtra cualquier nota inválida antes de guardar, como defensa adicional.
 */
export function saveNotes(notes) {
  try {
    const safeNotes = Array.isArray(notes) ? notes.filter(isValidNote) : [];
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(safeNotes));
    return true;
  } catch (error) {
    console.error("No se pudo guardar en Local Storage.", error);
    return false;
  }
}
