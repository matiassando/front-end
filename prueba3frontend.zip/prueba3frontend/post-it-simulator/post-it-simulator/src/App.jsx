// src/App.jsx
import { useEffect, useState } from "react";
import NoteForm from "./components/NoteForm";
import NoteBoard from "./components/NoteBoard";
import { loadNotes, saveNotes } from "./utils/storage";
import "./App.css";

function App() {
  // Carga inicial síncrona desde Local Storage (lazy initializer),
  // así la primera pintura ya muestra las notas guardadas.
  const [notes, setNotes] = useState(() => loadNotes());

  // Cada cambio en "notes" se persiste automáticamente.
  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  function handleAddNote({ title, description, important }) {
    const newNote = {
      id: crypto.randomUUID(),
      title,
      description,
      important,
      createdAt: Date.now(),
    };

    setNotes((current) => [newNote, ...current]);
  }

  function handleDeleteNote(id) {
    setNotes((current) => current.filter((note) => note.id !== id));
  }

  return (
    <div className="desk">
      <NoteForm onAddNote={handleAddNote} />
      <NoteBoard notes={notes} onDelete={handleDeleteNote} />
    </div>
  );
}

export default App;
